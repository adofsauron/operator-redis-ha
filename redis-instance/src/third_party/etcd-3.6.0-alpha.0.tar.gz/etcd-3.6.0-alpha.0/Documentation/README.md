The etcd docs are hosted at [etcd.io](https://etcd.io/), and so most files formerly in this directory have moved to the [website](https://github.com/etcd-io/website/) repo.
