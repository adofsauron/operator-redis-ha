# v1_handler_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exec** | [**v1_exec_action_t**](v1_exec_action.md) \* |  | [optional] 
**http_get** | [**v1_http_get_action_t**](v1_http_get_action.md) \* |  | [optional] 
**tcp_socket** | [**v1_tcp_socket_action_t**](v1_tcp_socket_action.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


