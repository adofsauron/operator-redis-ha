# extensions_v1beta1_http_ingress_rule_value_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paths** | [**list_t**](extensions_v1beta1_http_ingress_path.md) \* | A collection of paths that map requests to backends. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


