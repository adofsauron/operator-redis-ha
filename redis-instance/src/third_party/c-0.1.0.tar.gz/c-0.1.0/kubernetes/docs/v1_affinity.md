# v1_affinity_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**node_affinity** | [**v1_node_affinity_t**](v1_node_affinity.md) \* |  | [optional] 
**pod_affinity** | [**v1_pod_affinity_t**](v1_pod_affinity.md) \* |  | [optional] 
**pod_anti_affinity** | [**v1_pod_anti_affinity_t**](v1_pod_anti_affinity.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


