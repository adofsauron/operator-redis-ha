# extensions_v1beta1_rollback_config_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**revision** | **long** | The revision to rollback to. If set to 0, rollback to the last revision. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


