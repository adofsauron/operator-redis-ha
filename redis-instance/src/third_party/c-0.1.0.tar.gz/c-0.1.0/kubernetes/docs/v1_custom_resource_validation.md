# v1_custom_resource_validation_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**open_apiv3_schema** | [**v1_json_schema_props_t**](v1_json_schema_props.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


