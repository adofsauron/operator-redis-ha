# v1_attached_volume_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**device_path** | **char \*** | DevicePath represents the device path where the volume should be available | 
**name** | **char \*** | Name of the attached volume | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


