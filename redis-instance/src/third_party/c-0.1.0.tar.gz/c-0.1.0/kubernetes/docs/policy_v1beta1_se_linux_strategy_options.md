# policy_v1beta1_se_linux_strategy_options_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule** | **char \*** | rule is the strategy that will dictate the allowable labels that may be set. | 
**se_linux_options** | [**v1_se_linux_options_t**](v1_se_linux_options.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


