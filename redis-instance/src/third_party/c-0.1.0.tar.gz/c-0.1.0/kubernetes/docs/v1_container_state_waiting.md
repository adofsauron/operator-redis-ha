# v1_container_state_waiting_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **char \*** | Message regarding why the container is not yet running. | [optional] 
**reason** | **char \*** | (brief) reason the container is not yet running. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


