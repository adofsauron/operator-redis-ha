# v1_network_policy_peer_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip_block** | [**v1_ip_block_t**](v1_ip_block.md) \* |  | [optional] 
**namespace_selector** | [**v1_label_selector_t**](v1_label_selector.md) \* |  | [optional] 
**pod_selector** | [**v1_label_selector_t**](v1_label_selector.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


