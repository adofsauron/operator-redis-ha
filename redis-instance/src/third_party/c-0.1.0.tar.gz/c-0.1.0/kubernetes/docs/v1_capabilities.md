# v1_capabilities_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**add** | **list_t \*** | Added capabilities | [optional] 
**drop** | **list_t \*** | Removed capabilities | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


