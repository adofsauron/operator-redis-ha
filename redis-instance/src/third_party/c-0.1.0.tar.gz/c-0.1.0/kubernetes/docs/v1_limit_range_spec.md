# v1_limit_range_spec_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limits** | [**list_t**](v1_limit_range_item.md) \* | Limits is the list of LimitRangeItem objects that are enforced. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


