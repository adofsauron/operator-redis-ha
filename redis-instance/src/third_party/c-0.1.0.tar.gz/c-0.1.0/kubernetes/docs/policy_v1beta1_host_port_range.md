# policy_v1beta1_host_port_range_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | **int** | max is the end of the range, inclusive. | 
**min** | **int** | min is the start of the range, inclusive. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


