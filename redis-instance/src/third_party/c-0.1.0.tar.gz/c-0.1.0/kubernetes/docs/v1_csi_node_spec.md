# v1_csi_node_spec_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**drivers** | [**list_t**](v1_csi_node_driver.md) \* | drivers is a list of information of all CSI Drivers existing on a node. If all drivers in the list are uninstalled, this can become empty. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


