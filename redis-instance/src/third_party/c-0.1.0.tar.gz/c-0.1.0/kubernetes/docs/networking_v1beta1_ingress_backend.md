# networking_v1beta1_ingress_backend_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_name** | **char \*** | Specifies the name of the referenced service. | 
**service_port** | [**object_t**](.md) \* | Specifies the port of the referenced service. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


