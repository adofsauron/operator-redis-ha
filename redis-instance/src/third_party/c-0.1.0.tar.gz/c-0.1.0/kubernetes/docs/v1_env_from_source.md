# v1_env_from_source_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config_map_ref** | [**v1_config_map_env_source_t**](v1_config_map_env_source.md) \* |  | [optional] 
**prefix** | **char \*** | An optional identifier to prepend to each key in the ConfigMap. Must be a C_IDENTIFIER. | [optional] 
**secret_ref** | [**v1_secret_env_source_t**](v1_secret_env_source.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


