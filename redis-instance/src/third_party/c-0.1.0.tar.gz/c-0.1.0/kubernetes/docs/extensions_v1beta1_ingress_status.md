# extensions_v1beta1_ingress_status_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**load_balancer** | [**v1_load_balancer_status_t**](v1_load_balancer_status.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


