# v1_lifecycle_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**post_start** | [**v1_handler_t**](v1_handler.md) \* |  | [optional] 
**pre_stop** | [**v1_handler_t**](v1_handler.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


