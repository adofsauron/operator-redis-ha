# flowcontrol_v1alpha1_subject_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group** | [**v1alpha1_group_subject_t**](v1alpha1_group_subject.md) \* |  | [optional] 
**kind** | **char \*** | Required | 
**service_account** | [**v1alpha1_service_account_subject_t**](v1alpha1_service_account_subject.md) \* |  | [optional] 
**user** | [**v1alpha1_user_subject_t**](v1alpha1_user_subject.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


