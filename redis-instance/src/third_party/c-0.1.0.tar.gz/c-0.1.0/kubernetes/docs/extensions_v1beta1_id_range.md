# extensions_v1beta1_id_range_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max** | **long** | max is the end of the range, inclusive. | 
**min** | **long** | min is the start of the range, inclusive. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


