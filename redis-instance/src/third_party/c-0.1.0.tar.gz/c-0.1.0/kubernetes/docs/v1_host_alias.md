# v1_host_alias_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hostnames** | **list_t \*** | Hostnames for the above IP address. | [optional] 
**ip** | **char \*** | IP address of the host file entry. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


