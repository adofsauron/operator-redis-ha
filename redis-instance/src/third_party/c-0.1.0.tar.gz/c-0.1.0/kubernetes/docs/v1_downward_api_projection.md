# v1_downward_api_projection_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**list_t**](v1_downward_api_volume_file.md) \* | Items is a list of DownwardAPIVolume file | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


