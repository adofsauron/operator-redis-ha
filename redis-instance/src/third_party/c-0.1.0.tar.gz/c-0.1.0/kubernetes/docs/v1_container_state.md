# v1_container_state_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**running** | [**v1_container_state_running_t**](v1_container_state_running.md) \* |  | [optional] 
**terminated** | [**v1_container_state_terminated_t**](v1_container_state_terminated.md) \* |  | [optional] 
**waiting** | [**v1_container_state_waiting_t**](v1_container_state_waiting.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


