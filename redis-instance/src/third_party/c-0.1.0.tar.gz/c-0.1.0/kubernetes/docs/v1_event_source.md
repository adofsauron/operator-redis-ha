# v1_event_source_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component** | **char \*** | Component from which the event is generated. | [optional] 
**host** | **char \*** | Node name on which the event is generated. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


