# v1_env_var_source_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**config_map_key_ref** | [**v1_config_map_key_selector_t**](v1_config_map_key_selector.md) \* |  | [optional] 
**field_ref** | [**v1_object_field_selector_t**](v1_object_field_selector.md) \* |  | [optional] 
**resource_field_ref** | [**v1_resource_field_selector_t**](v1_resource_field_selector.md) \* |  | [optional] 
**secret_key_ref** | [**v1_secret_key_selector_t**](v1_secret_key_selector.md) \* |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


