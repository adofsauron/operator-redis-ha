# v1_group_version_for_discovery_t

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_version** | **char \*** | groupVersion specifies the API group and version in the form \&quot;group/version\&quot; | 
**version** | **char \*** | version specifies the version in the form of \&quot;version\&quot;. This is to save the clients the trouble of splitting the GroupVersion. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


