# Usage: 
# sh ./code-static-check.sh ${source_dir}

cppcheck --enable=all $*

